<p>Hello  <?php echo $user["userContact"]["fname"] ;?>,</p>
<p>Your password was successfully changed.</p>